<?php
	
	/**
	 * DB config
	*/

	
	define("BASEURL", 'http://localhost:8012/vino_me/'); // dev
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASSWORD', '');  
	define('DATABASE', 'vinodb');
?>