
<?php $__env->startSection('content'); ?>

<!-- Début form modif -->



        
        <div class="bg-gray-100  flex flex-col justify-center ">
            <div class="relative py-3  m-5">
                <div class="relative px-4 py-10 bg-white md:mx-8 shadow rounded-3xl sm:p-10">
                    <div class=" mx-auto">
                        <div class="flex items-center space-x-5">
                            <div class="h-11 w-11 rounded-full justify-center items-center text-yellow-500 text-2xl font-mono">
                                <img src="https://media.istockphoto.com/id/913518238/vector/silhouette-of-a-glass-wine-bottle.jpg?s=612x612&w=0&k=20&c=RYRdVJK8i4-M6oBVTDjnnNMFgFEua7uYVSSJI3LtpkM=" alt="">
                            </div>
                            <div class="block pl-2 font-semibold text-xl self-start text-gray-700">
                            <h2 class="leading-relaxed">Modification d'une bouteille</h2>
                            <p class="text-sm text-gray-500 font-normal leading-relaxed">Cellier : <?php echo e($cellier->nom_cellier); ?></p>
                            </div>
                        </div>

						<form id="formAjoutBouteille" action="<?php echo e(route('bouteille.update', ['idVin' => $bouteille->vino__bouteille_id, 'idCellier' => $bouteille->vino__cellier_id ])); ?>" method="POST">
							<?php echo csrf_field(); ?>
                        
                        <div class="divide-y divide-gray-200">
                            <div class="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                                <div class="flex flex-col">
                                    <label class="leading-loose">Nom</label>
                                    <input class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600" id="nom" name="nom" type="text" value="<?php echo e(old('nom', $bouteille->nom)); ?>" required>
                                </div>

                                
                                <label class="leading-loose">Type</label>
                                <div class="pb-2 flex items-center space-x-4 ">
                                    <input type="radio" name="type" id="rouge" value="1" required <?php if($bouteille->type == "1"): ?> checked <?php endif; ?> >
                                      <label for="rouge">Rouge</label>
                                      <input type="radio" name="type" id="blanc" value="2" <?php if($bouteille->type == "2"): ?> checked <?php endif; ?>>
                                      <label for="blanc">Blanc</label>
                                      <input type="radio" name="type" id="rose" value="3" <?php if($bouteille->type == "3"): ?> checked <?php endif; ?>>
                                    <label for="rose">Rosé</label>
                                </div>

                                
                                <div class="flex flex-col">
                                    <label class="leading-loose">Pays</label>
                                    <input class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600" id="pays" name="pays" type="text" value="<?php echo e(old('pays', $bouteille->pays)); ?>">
                                    <label class="leading-loose">Format</label>
                                    <input class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600" id="format" name="format" type="text" value="<?php echo e(old('format', $bouteille->format)); ?>">
									

								<?php $years = range(1900, strftime("%Y", time())); ?>
								<label class="leading-loose" for="millesime">Millesime :</label>
								<select id="millesime" name="millesime" class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600">
									<option value="<?php echo e($bouteille->millesime); ?>"><?php echo e($bouteille->millesime); ?></option>
									<?php foreach($years as $year) : ?>
									  <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
									<?php endforeach; ?>
								  </select>




                                    <label class="leading-loose">Description</label>
                                    <textarea class="px-4 py-2 border focus:ring-gray-500 focus:border-gray-900 w-full sm:text-sm border-gray-300 rounded-md focus:outline-none text-gray-600" id="description" name="description"><?php echo e(old('description', $bouteille->description)); ?></textarea>
                                </div>
                            </div>
                        </div>
						<button class="bg-red-800 flex justify-center items-center  text-white px-4 py-3 rounded-md focus:outline-none">Sauvegarder</button>
						</form>
					
                        
                            <div class="pt-4 flex flex-wrap items-center space-x-4">
                                
                                <form action="<?php echo e(route('bouteille.supprime', ['idVin' => $bouteille->id, 'idCellier' => $cellier->id ])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="bg-red-800 flex justify-center items-center  text-white px-3 py-3 rounded-md focus:outline-none">Supprimer</button>
                                </form>
                               
                                <a class="flex justify-center items-center  text-gray-900 px-4 py-3 rounded-md focus:outline-none" href='<?php echo e(route('bouteille.liste', ['id' => $bouteille->vino__cellier_id])); ?>'>
                                    <svg class="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg> Canceler
								</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views/bouteille/edit.blade.php ENDPATH**/ ?>