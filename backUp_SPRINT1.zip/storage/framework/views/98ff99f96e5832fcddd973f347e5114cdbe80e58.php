<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'w-full p-3  font-bold text-white bg-red-800 rounded my-5 focus:outline-none transition ease-in-out duration-150'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views/components/primary-button.blade.php ENDPATH**/ ?>