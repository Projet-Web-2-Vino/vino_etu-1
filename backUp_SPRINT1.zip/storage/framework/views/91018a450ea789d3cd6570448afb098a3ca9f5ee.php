<strong>Database Connected: </strong>
<?php

/* Test si connection BD */
    try {
        \DB::connection()->getPDO();
        echo \DB::connection()->getDatabaseName();
        } catch (\Exception $e) {
        echo 'None';
    }
?><?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views\testDB.blade.php ENDPATH**/ ?>