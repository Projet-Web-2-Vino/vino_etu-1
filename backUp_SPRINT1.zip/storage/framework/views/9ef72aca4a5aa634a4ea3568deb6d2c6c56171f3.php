

<?php $__env->startSection('content'); ?>




  
    
    <div class="py-8  grid place-items-center ">
        <h1 class="titleBouteille text-5xl  font-extrabold">L'atelier à vin</h1>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400 text-center">Bienvenue dans votre espace cellier : <?php echo e($cellier->nom_cellier); ?>.</p>
        <ul class="py-6 flex flex-wrap align-items-center justify-center  -mb-px text-sm font-medium text-center text-gray-500 dark:text-gray-400">
            

            <li class="mr-2">
                
                <button class=" inline-flex items-center text-sm font-medium mb-2  bg-red-800 px-3 py-2 hover:shadow-lg  text-white rounded-md hover:bg-red-600 ">
                    <span> 
                        <a class="btnModifier" href='/cellier'>Retour à votre espace cellier</a>
                    </span>
                </button>
            </li>

            <li class="mr-2">
                <button class=" inline-flex items-center text-sm font-medium mb-2  bg-red-800 px-3 py-2 hover:shadow-lg  text-white rounded-md hover:bg-red-600 ">
                    <span> 
                        <a href='<?php echo e(route('bouteille.nouveau', ['id' => $cellier->id])); ?>'>Ajouter une bouteille
                        </a>
                    </span>
                </button>
            </li>
            


        </ul>
    </div>

    <!-- Feedback success -->
    <?php if(session()->has('success')): ?>
    <div class="text-emerald-600 text-center font-semibold my-10"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
  

    <?php if(count($bouteilles) == 0): ?>
    <p>
        Vous n'avez aucune bouteille au cellier <em><?php echo e($cellier->nom_cellier); ?></em>
        <a href="<?php echo e(route('bouteille.nouveau', ['id' => $id_cellier ])); ?>">Ajouter une bouteille</a>
    </p>
    <?php endif; ?>



<div class="flex flex-wrap 	justify-evenly">
  <?php $__currentLoopData = $bouteilles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  <div class="w-fit py-3 mt-3 m-2  flex items-center bg-white shadow-md hover:shadow-xl rounded-lg">

    




    <img class="h-300 w-300" src="https://www.saq.com/media/catalog/product/1/2/12728904-1_1649076332.png?quality=80&fit=bounds&height=166&width=111&canvas=111:166">
    <div>
        <div class="px-3">
        
        <h3 class="titreBouteille"><strong><?php echo e($info->nom); ?></strong></h3>
        </div>

         

    <div class=" px-3 py-1 text-m font- justify-start">
        
        <small>

            
            <?php switch($info->type):

                case (1): ?>
                Vin Rouge
                <?php break; ?>

                <?php case (2): ?>
                Vin Blanc
                <?php break; ?>

                <?php case (3): ?>
                Vin Rosé
                <?php break; ?>

            <?php endswitch; ?>
            | <?php echo e($info->format); ?> | <?php echo e($info->pays); ?>  </small>
    </div>

    <div class=" py-1 flex px-3 space-x-2  text-sm font-medium justify-start">
        <p>Quantiter :</p>
        <p><?php echo e($info->quantite); ?></p>
        
    </div>


    <div class="text-sm font-medium justify-start">
        <span class="inline-block bg-gray-200 rounded-lg px-3 py-1 mt-2 ml-2 text-sm font-semibold text-gray-700 mr-2"><?php echo e($info->millesime); ?></span>
        
    </div>

     

   <div class="flex mt-6 mr-4 space-x-2 text-sm font-medium justify-start">


 
 <?php if($info->url_saq): ?>  
 <button class="transition ease-in duration-300 inline-flex items-center text-sm font-medium mb-2 md:mb-0 bg-red-800 px-3 py-2 hover:shadow-lg tracking-wider text-white rounded-md hover:bg-red-600 ">
   <span><a href="<?php echo e($info->url_saq); ?>">Voir SAQ</a></span>
 </button>
 <?php endif; ?>
        
        
        <button class="transition ease-in duration-300 inline-flex items-center text-sm font-medium mb-2 md:mb-0 bg-red-800 px-3 py-2 hover:shadow-lg tracking-wider text-white rounded-md hover:bg-red-600 ">
            <span> <a class="btnModifier" href="<?php echo e(route('bouteille.edit', ['idVin' => $info->vino__bouteille_id, 'idCellier' => $info->vino__cellier_id  ])); ?>">Modifier</a></span>
        </button>


            


            <span class="transition ease-in duration-300 inline-flex items-center text-sm font-medium mb-2 md:mb-0 bg-gray-200 px-3 py-2 hover:shadow-lg tracking-wider text-gray-700 rounded-md hover:bg-gray-700 hover:text-gray-200 ">
                <form action="<?php echo e(route('bouteille.supprime', ['idVin' => $info->vino__bouteille_id, 'idCellier' => $info->vino__cellier_id ])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button><i class="fa-solid fa-trash"></i></button>
                </form>

            </span>
        

        
      </div>
    </div>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
  <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views/bouteille/liste.blade.php ENDPATH**/ ?>