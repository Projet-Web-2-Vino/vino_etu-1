# Revue du sprint #0

La phase préparatoire du sprint 0 était ardue. L'équipe ne semblait pas au début avoir la même vision de l'application à développer. Petit à petit, en investiguant dans le code source et en réflichissant sur les schémas de la base de données, la vision fut plus claire.

Nous avons donc commencer à revoir les interfaces graphique et les relation des schémas de la bd.

En investiguant dans le code source, nous avions également une meilleure idée si l'utilisation d'un framework était envisageable.

En somme, la phase préparative s'est bien déroulée. nous avons eu les réponses à nos questionnements et nous avons pu être capable de mieux planifier le sprint #1.

Voir planification sprint # 0 dans le ScrumDesk : 
https://app.scrumdesk.com/#/projects/36882/plan