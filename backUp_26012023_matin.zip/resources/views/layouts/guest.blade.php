<div class=" h-screen overflow-hidden flex items-center justify-center ">
 {{ $slot }}
</div>
 
