<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CelliersBouteillesController extends Controller
{
    //
    public function getCount($id)
    {
        
    }
}
