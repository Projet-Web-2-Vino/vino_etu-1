

<?php $__env->startSection('content'); ?>

<!-- Pour tester des routes -->

<a href="/cellier">Espace cellier</a>
<a href="<?php echo e(route('bouteille.nouveau', ['id' => $id_cellier ])); ?>">Ajouter une bouteille</a>



 <?php $__env->slot('header', null, []); ?> 

<?php if($msg): ?>
<p><?php echo e($msg); ?></p>
<?php endif; ?>

<!-- pour information seulement pour tester -->
<div>
id_usager = <?php echo e($id_usager); ?> <br>
id_cellier = <?php echo e($id_cellier); ?> <br>
</div>


<?php if(session('success')): ?>
<p style="font-size:1.3em; color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>


<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">
                <div class="cellier grid">
                    <?php
                    foreach ($data as $cle => $bouteille) {
                    ?>
                        <div class="bouteille" data-quantite="<?php echo $bouteille['quantite'] ?>">
                            <a class="btnModifier" href='<?php echo e(route('bouteille.edit', ['id' => $bouteille->id ])); ?>'>Modifier</a>
                            <div class="img">
                                <img src="https:<?php echo $bouteille['image'] ?>">
                            </div>
                            <h5><?php echo $bouteille['nom'] ?></h5>
                            <div class="description">
                                <p class="quantite">Quantité : <?php echo $bouteille['quantite'] ?></p>
                                <p class="pays">Pays : <?php echo $bouteille['pays'] ?></p>
                                <p class="type">Type : <?php echo $bouteille['type'] ?></p>
                                <p class="millesime">Millesime : <?php echo $bouteille['millesime'] ?></p>
                                <p><a href="<?php echo $bouteille['url_saq'] ?>">Voir SAQ</a></p>
                            </div>
                            <div class="options" data-id="<?php echo $bouteille['id_bouteille_cellier'] ?>" data-id-vin="<?php echo $bouteille['id_bouteille'] ?>">
                                <!-- <button class='btnModifier'>Modifier</button> -->



                                    <button class='btnAjouter'>Ajouter</button>

                                    <button class='btnAjouter'>Ajouter</button>
                            </div>

                <?php
                    }
                ?>



     <?php $__env->slot('header', null, []); ?> 

    <?php if($msg): ?>
    <p><?php echo e($msg); ?></p>
    <?php endif; ?>


    <h1>Vue : Liste Bouteilles du catalogue</h1>
    <?php if(session('success')): ?>
    <p style="font-size:1.3em; color: green;"><?php echo e(session('success')); ?></p>

    <?php endif; ?>
     <?php $__env->endSlot(); ?>




    <div class="container mx-auto">
    <div class="flex flex-wrap -mx-4">
      <div class="w-full sm:w-1/2 md:w-1/2 xl:w-1/4 p-4">
        <a href="" class="c-card block bg-white shadow-md hover:shadow-xl rounded-lg overflow-hidden">
        <div class="relative pb-48 overflow-hidden">
          <img class="absolute inset-0 h-full w-full object-cover" src="https://images.unsplash.com/photo-1475855581690-80accde3ae2b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80" alt="">
        </div>
        <div class="p-4">
          <span class="inline-block px-2 py-1 leading-none bg-orange-200 text-orange-800 rounded-full font-semibold uppercase tracking-wide text-xs">Highlight</span>
          <h2 class="mt-2 mb-2  font-bold">Purus Ullamcorper Inceptos Nibh</h2>
          <p class="text-sm">Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec ullamcorper nulla non metus auctor fringilla.</p>
          <div class="mt-3 flex items-center">
            <span class="text-sm font-semibold">ab</span>&nbsp;<span class="font-bold text-xl">45,00</span>&nbsp;<span class="text-sm font-semibold">€</span>
          </div>
        </div>
        <div class="p-4 border-t border-b text-xs text-gray-700">
          <span class="flex items-center mb-1">
            <i class="far fa-clock fa-fw mr-2 text-gray-900"></i> 3 Tage
          </span>
          <span class="flex items-center">
            <i class="far fa-address-card fa-fw text-gray-900 mr-2"></i> Ermäßigung mit Karte
          </span>
        </div>
        <div class="p-4 flex items-center text-sm text-gray-600"><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 fill-current text-yellow-500"><path d="M8.128 19.825a1.586 1.586 0 0 1-1.643-.117 1.543 1.543 0 0 1-.53-.662 1.515 1.515 0 0 1-.096-.837l.736-4.247-3.13-3a1.514 1.514 0 0 1-.39-1.569c.09-.271.254-.513.475-.698.22-.185.49-.306.776-.35L8.66 7.73l1.925-3.862c.128-.26.328-.48.577-.633a1.584 1.584 0 0 1 1.662 0c.25.153.45.373.577.633l1.925 3.847 4.334.615c.29.042.562.162.785.348.224.186.39.43.48.704a1.514 1.514 0 0 1-.404 1.58l-3.13 3 .736 4.247c.047.282.014.572-.096.837-.111.265-.294.494-.53.662a1.582 1.582 0 0 1-1.643.117l-3.865-2-3.865 2z"></path></svg><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 fill-current text-yellow-500"><path d="M8.128 19.825a1.586 1.586 0 0 1-1.643-.117 1.543 1.543 0 0 1-.53-.662 1.515 1.515 0 0 1-.096-.837l.736-4.247-3.13-3a1.514 1.514 0 0 1-.39-1.569c.09-.271.254-.513.475-.698.22-.185.49-.306.776-.35L8.66 7.73l1.925-3.862c.128-.26.328-.48.577-.633a1.584 1.584 0 0 1 1.662 0c.25.153.45.373.577.633l1.925 3.847 4.334.615c.29.042.562.162.785.348.224.186.39.43.48.704a1.514 1.514 0 0 1-.404 1.58l-3.13 3 .736 4.247c.047.282.014.572-.096.837-.111.265-.294.494-.53.662a1.582 1.582 0 0 1-1.643.117l-3.865-2-3.865 2z"></path></svg><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 fill-current text-yellow-500"><path d="M8.128 19.825a1.586 1.586 0 0 1-1.643-.117 1.543 1.543 0 0 1-.53-.662 1.515 1.515 0 0 1-.096-.837l.736-4.247-3.13-3a1.514 1.514 0 0 1-.39-1.569c.09-.271.254-.513.475-.698.22-.185.49-.306.776-.35L8.66 7.73l1.925-3.862c.128-.26.328-.48.577-.633a1.584 1.584 0 0 1 1.662 0c.25.153.45.373.577.633l1.925 3.847 4.334.615c.29.042.562.162.785.348.224.186.39.43.48.704a1.514 1.514 0 0 1-.404 1.58l-3.13 3 .736 4.247c.047.282.014.572-.096.837-.111.265-.294.494-.53.662a1.582 1.582 0 0 1-1.643.117l-3.865-2-3.865 2z"></path></svg><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 fill-current text-yellow-500"><path d="M8.128 19.825a1.586 1.586 0 0 1-1.643-.117 1.543 1.543 0 0 1-.53-.662 1.515 1.515 0 0 1-.096-.837l.736-4.247-3.13-3a1.514 1.514 0 0 1-.39-1.569c.09-.271.254-.513.475-.698.22-.185.49-.306.776-.35L8.66 7.73l1.925-3.862c.128-.26.328-.48.577-.633a1.584 1.584 0 0 1 1.662 0c.25.153.45.373.577.633l1.925 3.847 4.334.615c.29.042.562.162.785.348.224.186.39.43.48.704a1.514 1.514 0 0 1-.404 1.58l-3.13 3 .736 4.247c.047.282.014.572-.096.837-.111.265-.294.494-.53.662a1.582 1.582 0 0 1-1.643.117l-3.865-2-3.865 2z"></path></svg><svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 fill-current text-gray-400"><path d="M8.128 19.825a1.586 1.586 0 0 1-1.643-.117 1.543 1.543 0 0 1-.53-.662 1.515 1.515 0 0 1-.096-.837l.736-4.247-3.13-3a1.514 1.514 0 0 1-.39-1.569c.09-.271.254-.513.475-.698.22-.185.49-.306.776-.35L8.66 7.73l1.925-3.862c.128-.26.328-.48.577-.633a1.584 1.584 0 0 1 1.662 0c.25.153.45.373.577.633l1.925 3.847 4.334.615c.29.042.562.162.785.348.224.186.39.43.48.704a1.514 1.514 0 0 1-.404 1.58l-3.13 3 .736 4.247c.047.282.014.572-.096.837-.111.265-.294.494-.53.662a1.582 1.582 0 0 1-1.643.117l-3.865-2-3.865 2z"></path></svg><span class="ml-2">34 Bewertungen</span></div>
      </a>
      </div>






    </div>
  </div>

  <?php $__env->stopSection(); ?>
=======

<div class="p-6 text-gray-900">
    <div class="cellier grid">
        <?php if(count($bouteilles) == 0): ?>
        <p>
            Vous n'avez aucune bouteille au cellier <em><?php echo e($cellier->nom_cellier); ?></em>
            <a href="<?php echo e(route('bouteille.nouveau', ['id' => $id_cellier ])); ?>">Ajouter une bouteille</a>
        </p>
        <?php else: ?>
        <h1>Liste bouteilles du cellier  <em><?php echo e($cellier->nom_cellier); ?></em> </h1>
        <?php endif; ?>

        <?php $__currentLoopData = $bouteilles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <div class="bouteille" data-quantite="<?php echo e($info->quantite); ?>">
               
                <div class="img">
                   <!-- <img src="<?php echo e($info->image); ?>"> -->
                    <img src="https://www.saq.com/media/catalog/product/">
                </div>
                <a href="<?php echo e(route('bouteille.edit', ['idVin' => $info->vino__bouteille_id, 'idCellier' => $info->vino__cellier_id  ])); ?>">Éditer</a>
                <h3><?php echo e($info->nom); ?></h3>                                                       
                <div class="description">
                    <p class="quantite">Quantité : <?php echo e($info->quantite); ?></p>
                    <p class="pays">Pays : <?php echo e($info->pays); ?></p>
                    <p class="type">Type : <?php echo e($info->type); ?></p>
                    <p class="millesime">Millesime : <?php echo e($info->millesime); ?></p>
                    <p><a href="<?php echo e($info->url_saq); ?>">Voir SAQ</a></p>
                </div>
                <div class="options" data-id="<?php echo e($info->vino__cellier_id); ?>" data-id-vin="<?php echo e($info->vino__bouteille_id); ?>">
                    <!-- <button class='btnModifier'>Modifier</button> -->
                        <button class='btnAjouter'>Ajouter</button>
                        <button class='btnAjouter'>Boire</button>
                </div>
            </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views\bouteille\liste.blade.php ENDPATH**/ ?>