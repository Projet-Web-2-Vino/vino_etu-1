<div class=" h-screen overflow-hidden flex items-center justify-center ">
 <?php echo e($slot); ?>

</div>
 
<?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views\layouts\guest.blade.php ENDPATH**/ ?>