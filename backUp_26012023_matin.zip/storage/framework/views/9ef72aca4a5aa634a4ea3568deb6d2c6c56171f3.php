<!-- Pour tester des routes -->

<a href="/cellier">Espace cellier</a>
<a href="<?php echo e(route('bouteille.nouveau', ['id' => $id_cellier ])); ?>">Ajouter une bouteille</a>

  
<?php if($msg): ?>
<p><?php echo e($msg); ?></p>
<?php endif; ?>

<!-- pour information seulement pour tester -->
<div>
id_usager = <?php echo e($id_usager); ?> <br>
id_cellier = <?php echo e($id_cellier); ?> <br>
</div>


<?php if(session('success')): ?>
<p style="font-size:1.3em; color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>


<div class="p-6 text-gray-900">
    <div class="cellier grid">
        <?php if(count($bouteilles) == 0): ?>
        <p>
            Vous n'avez aucune bouteille au cellier <em><?php echo e($cellier->nom_cellier); ?></em>
            <a href="<?php echo e(route('bouteille.nouveau', ['id' => $id_cellier ])); ?>">Ajouter une bouteille</a>
        </p>
        <?php else: ?>
        <h1>Liste bouteilles du cellier  <em><?php echo e($cellier->nom_cellier); ?></em> </h1>
        <?php endif; ?>

        <?php $__currentLoopData = $bouteilles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <div class="bouteille" data-quantite="<?php echo e($info->quantite); ?>">
               
                <div class="img">
                   <!-- <img src="<?php echo e($info->image); ?>"> -->
                    <img src="https://www.saq.com/media/catalog/product/">
                </div>
                <a href="<?php echo e(route('bouteille.edit', ['idVin' => $info->vino__bouteille_id, 'idCellier' => $info->vino__cellier_id  ])); ?>">Éditer</a>
                <h3><?php echo e($info->nom); ?></h3>                                                       
                <div class="description">
                    <p class="quantite">Quantité : <?php echo e($info->quantite); ?></p>
                    <p class="pays">Pays : <?php echo e($info->pays); ?></p>
                    <p class="type">Type : <?php echo e($info->type); ?></p>
                    <p class="millesime">Millesime : <?php echo e($info->millesime); ?></p>
                    <p><a href="<?php echo e($info->url_saq); ?>">Voir SAQ</a></p>
                </div>
                <div class="options" data-id="<?php echo e($info->vino__cellier_id); ?>" data-id-vin="<?php echo e($info->vino__bouteille_id); ?>">
                    <!-- <button class='btnModifier'>Modifier</button> -->
                        <button class='btnAjouter'>Ajouter</button>
                        <button class='btnAjouter'>Boire</button>
                </div>
            </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views/bouteille/liste.blade.php ENDPATH**/ ?>