
<a href="/cellier">Espace cellier</a>

<!-- pour information seulement pour tester -->
<div>
	id_vin = <?php echo e($bouteille->vino__bouteille_id); ?> <br>
	id_cellier = <?php echo e($bouteille->vino__cellier_id); ?> <br>
	</div>

<h1>
	Modification de la bouteille <br>
	<em><?php echo e($bouteille->nom); ?></em> <br>
	provenant du cellier <br>
	<em><?php echo e($cellier->nom_cellier); ?></em>
</h1>
<?php if(session()->has('success')): ?>
<span style="color:green"><?php echo e(session('success')); ?></span>
<?php endif; ?>

<!-- Début form modif -->

	<form id="formEditBouteille" action="<?php echo e(route('bouteille.update', ['id' => $bouteille->id])); ?>" method="POST">
		<?php echo csrf_field(); ?>
	
		 <!-- Obligatoire -->
		  <label for="nom"> * Nom  :</label>
		  <input id="nom" name="nom" type="text" value="<?php echo e(old('nom', $bouteille->nom)); ?>" required>
		  <br>

          
		  <span>* Type :</span>
		  <br>
		  <input type="radio" name="type" id="rouge" value="1" required <?php if($bouteille->type == "1"): ?> checked <?php endif; ?> >
		  <label for="rouge">Rouge</label>
		  <input type="radio" name="type" id="blanc" value="2" <?php if($bouteille->type == "2"): ?> checked <?php endif; ?>>
		  <label for="blanc">Blanc</label>
		  <input type="radio" name="type" id="rose" value="3" <?php if($bouteille->type == "3"): ?> checked <?php endif; ?>>
		  <label for="rose">Rosé</label>
		  <br>
		  <label for="quantite">Quantité :</label>
		  <input id="quantite" name="quantite" type="text" value="<?php echo e(old('quantite', $bouteille->quantite)); ?>" required>
		  <br>
		  <!-- Pas obligatoire -->
		  <label for="pays">Pays :</label>
		  <input id="pays" name="pays" type="text" value="<?php echo e(old('pays', $bouteille->pays)); ?>">
		  <br>
		  <label for="format">Format :</label>
		  <input id="format" name="format" type="text" value="<?php echo e(old('format', $bouteille->format)); ?>">
		  <br>
		  <label for="millesime">Millesime :</label>
		  <input id="millesime" name="millesime" type="text" value="<?php echo e(old('millesime', $bouteille->millesime)); ?>">
		  <br>
		  <label for="description">Description</label>
		  <textarea id="description" name="description"><?php echo e(old('description', $bouteille->description)); ?></textarea>
		  <br>
		  <!-- Caché non obligatoire -->
		  <input id="url_saq" name="url_saq" type="hidden" value="<?php echo e(old('url_saq', $bouteille->url_saq)); ?>">
		  <input id="code_saq" name="code_saq" type="hidden" value="<?php echo e(old('code_saq', $bouteille->code_saq)); ?>">
		  <input id="image" name="image" type="hidden" value="<?php echo e(old('image', $bouteille->image)); ?>">
		  <input id="prix_saq" name="prix_saq" type="hidden" value="<?php echo e(old('prix_saq', $bouteille->prix_saq)); ?>">
		  <input id="url_img" name="url_img" type="hidden" value="<?php echo e(old('url_img', $bouteille->url_img)); ?>">
	
		  <button>Modifier</button>

		</form>

        <form action="<?php echo e(route('bouteille.supprime', ['id' => $bouteille->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
        
            <button>Supprimer</button>
        </form>


<?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views\bouteille\edit.blade.php ENDPATH**/ ?>