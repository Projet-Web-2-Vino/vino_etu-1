
<h1>Espace cellier</h1>
<h4>Modification</h4>
<?php if(session()->has('success')): ?>
<span style="color:green"><?php echo e(session('success')); ?></span>
<?php endif; ?>


<form action="<?php echo e(route('cellier.update', ['id' => $cellier->id])); ?>" method="POST">

    <?php echo csrf_field(); ?>

    <label style="display: block;">
        Nom du cellier <input name="nom_cellier" type="text" value="<?php echo e(old('nom_cellier', $cellier->nom_cellier)); ?>" />
        <?php $__errorArgs = ['nom_cellier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span style="color:red"> <?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
    <!--TODO ajout de l'id de l'usager -->
    <input name="id_usager" type="hidden" value="<?php echo e(Auth::id()); ?>" />
    <button>Sauvegarde</button>

</form>

<?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views\cellier\edit.blade.php ENDPATH**/ ?>