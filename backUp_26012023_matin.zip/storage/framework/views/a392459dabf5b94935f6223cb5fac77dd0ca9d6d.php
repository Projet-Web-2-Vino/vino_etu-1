

<?php $__env->startSection('content'); ?>

<!-- <a href="/SAQ">Importer le catalogue</a><br> -->
<!-- idUsager = <?php echo e($id_usager); ?> <br> -->





<div class="py-5 font-bold text-5xl text-center">
  <h1>Espace cellier</h1>
</div>


  <div class="px-2 py-4   m-2 mx-auto bg-white rounded-lg text-center">
      <a class="inline-block bg-red-800 rounded px-3 py-1 text-sm font-semibold text-white mr-2" href='cellier/nouveau'>Ajouter un cellier</a>
  </div>

  <?php if(count($celliers) == 0): ?>
  <div class="py-3 font-bold text-2xl text-center">
      <h3>Veuillez ajouter un cellier</h3>
  </div>
  <?php else: ?>
  <div class="py-3 font-bold text-2xl text-center">
    <h3 class="uppercase">Vos celliers</h3>
</div>
  <?php endif; ?>

  <?php if(session()->has('success')): ?>
  <div class="text-emerald-600 text-center font-semibold my-10"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

<div class='max-w-full p-10'>
    <div class="relative gap-5  items-center w-full  rounded-lg focus-within:shadow-lg bg-white overflow-hidden">
       <!--
      <div class="grid place-items-center h-full w-12 text-gray-300">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
        </div>


 Recherche de cellier TODO if TIME
<input class="peer h-full w-full border-none text-sm text-gray-700 pr-2" type="text" placeholder="Recherche Cellier.." />
-->


    
    <?php if($celliers): ?>
    <?php $__currentLoopData = $celliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class=" px-5 my-10 grow bg-white rounded-lg shadow-xl">
        <div class="text-right">
           <!-- zone edit cellier-->
           <span class="inline-block bg-gray-200 rounded px-3 py-1 text-xl font-semibold text-gray-700 mr-2"><a href="<?php echo e(route('cellier.edit', ['id' => $info->id ])); ?>"><i class="far fa-edit"></i></a></span>
           <!-- zone delete cellier-->
         <span class="inline-block bg-gray-200 rounded px-3 py-1 text-xl font-semibold text-gray-700">
             <form action="<?php echo e(route('cellier.supprime', ['id' => $info->id])); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <button><i class="fa-solid fa-trash"></i></button>
             </form>

         </span>
        </div>
        <div class="p-4 flex flex-col justify-between leading-normal">
          <div class="mb-3">
            
            <h2 class="text-xl uppercase font-bold"><?php echo e($info->nom_cellier); ?> </h2>
            
            <small class="inline-block   py-1 pb-2 mt-1 text-sm font-semibold  mr-2"><p>Nombre de bouteille : <?php echo e($info->bouteilles_count); ?></p></small><br>
            <a class="inline-block bg-red-800 rounded px-3 py-1 text-sm font-semibold text-white mr-2" href='<?php echo e(route('bouteille.nouveau', ['id' => $info->id ])); ?>'>Ajouter une bouteille</a>
            
          </div>
          <div>
            
         
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annab\OneDrive\Bureau\ProjetWeb2\_laravel\vino-app\resources\views/cellier/index.blade.php ENDPATH**/ ?>